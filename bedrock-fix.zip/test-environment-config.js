#!/usr/bin/env node

/**
 * Test script for environment variable configuration
 * Validates that EXTERNAL_ACCESS_ENABLED works correctly
 */

const { handler } = require('./dist/router');

// Test configuration
const TEST_CONFIG = {
  VALID_API_KEY: 'test-api-key-12345678901234567890',
  VERBOSE: process.env.VERBOSE === 'true'
};

// Mock Lambda context
const mockContext = {
  awsRequestId: 'env-test-' + Date.now(),
  functionName: 'vibe-pm-agent-env-test',
  invokedFunctionArn: 'arn:aws:lambda:us-east-1:123456789012:function:vibe-pm-agent-env',
  remainingTimeInMillis: 30000,
  callbackWaitsForEmptyEventLoop: false
};

// Test results
const testResults = {
  passed: 0,
  failed: 0,
  tests: []
};

/**
 * Log test result
 */
function logTest(testName, passed, details = null, error = null) {
  const status = passed ? '✅ PASS' : '❌ FAIL';
  console.log(`${status} ${testName}`);
  
  if (TEST_CONFIG.VERBOSE && details) {
    console.log(`   Details: ${JSON.stringify(details, null, 2)}`);
  }
  
  if (error) {
    console.log(`   Error: ${error}`);
  }
  
  testResults.tests.push({
    name: testName,
    passed,
    details,
    error
  });
  
  if (passed) {
    testResults.passed++;
  } else {
    testResults.failed++;
  }
}

/**
 * Test external access enabled
 */
async function testExternalAccessEnabled() {
  // Set environment variable
  process.env.EXTERNAL_ACCESS_ENABLED = 'true';
  
  const event = {
    requestContext: {
      identity: { sourceIp: '192.168.1.1' },
      requestId: 'env-test-enabled'
    },
    headers: {
      'Content-Type': 'application/json',
      'X-API-Key': TEST_CONFIG.VALID_API_KEY
    },
    httpMethod: 'POST',
    path: '/tools',
    body: JSON.stringify({
      toolName: 'validate_idea_quick',
      toolArgs: {
        idea: 'Test with external access enabled',
        criteria: ['feasibility']
      }
    })
  };

  try {
    const result = await handler(event, mockContext);
    const passed = result.statusCode === 200;
    
    logTest('External Access Enabled', passed, {
      statusCode: result.statusCode,
      externalAccessEnabled: process.env.EXTERNAL_ACCESS_ENABLED,
      authenticated: passed
    }, passed ? null : `Expected 200 when external access enabled, got ${result.statusCode}`);
    
    return passed;
  } catch (error) {
    logTest('External Access Enabled', false, null, error.message);
    return false;
  }
}

/**
 * Test external access disabled
 */
async function testExternalAccessDisabled() {
  // Set environment variable
  process.env.EXTERNAL_ACCESS_ENABLED = 'false';
  
  const event = {
    requestContext: {
      identity: { sourceIp: '192.168.1.1' },
      requestId: 'env-test-disabled'
    },
    headers: {
      'Content-Type': 'application/json',
      'X-API-Key': TEST_CONFIG.VALID_API_KEY
    },
    httpMethod: 'POST',
    path: '/tools',
    body: JSON.stringify({
      toolName: 'validate_idea_quick',
      toolArgs: {
        idea: 'Test with external access disabled',
        criteria: ['feasibility']
      }
    })
  };

  try {
    const result = await handler(event, mockContext);
    const passed = result.statusCode === 403;
    
    logTest('External Access Disabled', passed, {
      statusCode: result.statusCode,
      externalAccessEnabled: process.env.EXTERNAL_ACCESS_ENABLED,
      blocked: passed
    }, passed ? null : `Expected 403 when external access disabled, got ${result.statusCode}`);
    
    return passed;
  } catch (error) {
    logTest('External Access Disabled', false, null, error.message);
    return false;
  }
}

/**
 * Test internal access unaffected by external access setting
 */
async function testInternalAccessUnaffected() {
  const tests = [
    { externalAccess: 'true', name: 'Internal Access (External Enabled)' },
    { externalAccess: 'false', name: 'Internal Access (External Disabled)' }
  ];

  let allPassed = true;

  for (const test of tests) {
    process.env.EXTERNAL_ACCESS_ENABLED = test.externalAccess;
    
    const event = {
      toolName: 'validate_idea_quick',
      toolArgs: {
        idea: 'Internal test with external access ' + test.externalAccess,
        criteria: ['feasibility']
      },
      source: 'bedrock-agent'
    };

    try {
      const result = await handler(event, mockContext);
      const passed = result.success === true;
      
      logTest(test.name, passed, {
        success: result.success,
        externalAccessEnabled: process.env.EXTERNAL_ACCESS_ENABLED,
        toolName: result.toolName
      }, passed ? null : `Internal access failed when external access is ${test.externalAccess}`);
      
      if (!passed) allPassed = false;
    } catch (error) {
      logTest(test.name, false, null, error.message);
      allPassed = false;
    }
  }

  return allPassed;
}

/**
 * Test health check unaffected by external access setting
 */
async function testHealthCheckUnaffected() {
  const tests = [
    { externalAccess: 'true', name: 'Health Check (External Enabled)' },
    { externalAccess: 'false', name: 'Health Check (External Disabled)' }
  ];

  let allPassed = true;

  for (const test of tests) {
    process.env.EXTERNAL_ACCESS_ENABLED = test.externalAccess;
    
    const event = {
      requestContext: {
        identity: { sourceIp: '192.168.1.1' },
        requestId: 'health-test-' + test.externalAccess
      },
      headers: {
        'Content-Type': 'application/json'
      },
      httpMethod: 'GET',
      path: '/health'
    };

    try {
      const result = await handler(event, mockContext);
      const passed = result.statusCode === 200;
      
      logTest(test.name, passed, {
        statusCode: result.statusCode,
        externalAccessEnabled: process.env.EXTERNAL_ACCESS_ENABLED,
        status: result.body ? JSON.parse(result.body).status : null
      }, passed ? null : `Health check failed when external access is ${test.externalAccess}`);
      
      if (!passed) allPassed = false;
    } catch (error) {
      logTest(test.name, false, null, error.message);
      allPassed = false;
    }
  }

  return allPassed;
}

/**
 * Test environment variable edge cases
 */
async function testEnvironmentEdgeCases() {
  const tests = [
    { value: undefined, name: 'Undefined Environment Variable', expectedBehavior: 'disabled' },
    { value: '', name: 'Empty Environment Variable', expectedBehavior: 'disabled' },
    { value: 'TRUE', name: 'Uppercase TRUE', expectedBehavior: 'enabled' },
    { value: 'True', name: 'Mixed Case True', expectedBehavior: 'enabled' },
    { value: '1', name: 'Numeric 1', expectedBehavior: 'enabled' },
    { value: 'yes', name: 'String "yes"', expectedBehavior: 'enabled' },
    { value: 'false', name: 'String "false"', expectedBehavior: 'disabled' },
    { value: '0', name: 'Numeric 0', expectedBehavior: 'disabled' }
  ];

  let allPassed = true;

  for (const test of tests) {
    // Set or delete environment variable
    if (test.value === undefined) {
      delete process.env.EXTERNAL_ACCESS_ENABLED;
    } else {
      process.env.EXTERNAL_ACCESS_ENABLED = test.value;
    }
    
    const event = {
      requestContext: {
        identity: { sourceIp: '192.168.1.1' },
        requestId: 'edge-test-' + (test.value || 'undefined')
      },
      headers: {
        'Content-Type': 'application/json',
        'X-API-Key': TEST_CONFIG.VALID_API_KEY
      },
      httpMethod: 'POST',
      path: '/tools',
      body: JSON.stringify({
        toolName: 'validate_idea_quick',
        toolArgs: {
          idea: 'Edge case test',
          criteria: ['feasibility']
        }
      })
    };

    try {
      const result = await handler(event, mockContext);
      
      const expectedStatusCode = test.expectedBehavior === 'enabled' ? 200 : 403;
      const passed = result.statusCode === expectedStatusCode;
      
      logTest(`Environment Edge Case: ${test.name}`, passed, {
        envValue: test.value,
        expectedBehavior: test.expectedBehavior,
        statusCode: result.statusCode,
        expectedStatusCode
      }, passed ? null : `Expected ${expectedStatusCode} for ${test.name}, got ${result.statusCode}`);
      
      if (!passed) allPassed = false;
    } catch (error) {
      logTest(`Environment Edge Case: ${test.name}`, false, null, error.message);
      allPassed = false;
    }
  }

  return allPassed;
}

/**
 * Run all environment configuration tests
 */
async function runAllTests() {
  console.log('⚙️  Starting Environment Configuration Tests');
  console.log('Testing EXTERNAL_ACCESS_ENABLED environment variable behavior');
  console.log('');

  // Set credential path
  process.env.CREDENTIAL_PATH = '../.aws/api-keys.json';

  console.log('🔧 Testing Basic Configuration...');
  await testExternalAccessEnabled();
  await testExternalAccessDisabled();
  console.log('');

  console.log('🔄 Testing Internal Access Independence...');
  await testInternalAccessUnaffected();
  console.log('');

  console.log('🏥 Testing Health Check Independence...');
  await testHealthCheckUnaffected();
  console.log('');

  console.log('🎯 Testing Environment Variable Edge Cases...');
  await testEnvironmentEdgeCases();
  console.log('');

  // Print test summary
  console.log('📊 Test Summary');
  console.log('================');
  console.log(`✅ Passed: ${testResults.passed}`);
  console.log(`❌ Failed: ${testResults.failed}`);
  console.log(`📈 Success Rate: ${((testResults.passed / (testResults.passed + testResults.failed)) * 100).toFixed(1)}%`);
  
  if (testResults.failed > 0) {
    console.log('\n❌ Failed Tests:');
    testResults.tests.filter(t => !t.passed).forEach(test => {
      console.log(`   • ${test.name}: ${test.error || 'Unknown error'}`);
    });
  }

  console.log('\n🎯 Key Findings:');
  console.log('   • EXTERNAL_ACCESS_ENABLED=true enables external API access');
  console.log('   • EXTERNAL_ACCESS_ENABLED=false blocks external API access');
  console.log('   • Internal access works regardless of external access setting');
  console.log('   • Health check works regardless of external access setting');
  console.log('   • Environment variable handles edge cases correctly');

  // Restore default setting
  process.env.EXTERNAL_ACCESS_ENABLED = 'true';

  // Exit with appropriate code
  process.exit(testResults.failed > 0 ? 1 : 0);
}

/**
 * Main execution
 */
if (require.main === module) {
  runAllTests().catch(error => {
    console.error('❌ Test execution failed:', error.message);
    process.exit(1);
  });
}

module.exports = {
  runAllTests,
  testExternalAccessEnabled,
  testExternalAccessDisabled,
  testInternalAccessUnaffected,
  testEnvironmentEdgeCases
};