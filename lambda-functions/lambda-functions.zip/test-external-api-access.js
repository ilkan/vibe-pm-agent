#!/usr/bin/env node
"use strict";
/**
 * Comprehensive test script for external API access with API key authentication
 * Tests all MCP tools through the external API Gateway endpoint
 */
const https = require('https');
const crypto = require('crypto');
// Configuration
const CONFIG = {
    // API Gateway URL (replace with actual deployed URL)
    API_BASE_URL: process.env.API_GATEWAY_URL || 'https://your-api-id.execute-api.us-east-1.amazonaws.com/dev',
    // Test API keys
    VALID_API_KEY: 'test-api-key-12345678901234567890', // Raw key that hashes to stored value
    INVALID_API_KEY: 'invalid-key-123',
    // Test timeout
    REQUEST_TIMEOUT: 30000,
    // Test configuration
    VERBOSE: process.env.VERBOSE === 'true',
    PARALLEL_TESTS: process.env.PARALLEL_TESTS === 'true'
};
// Test results tracking
const testResults = {
    passed: 0,
    failed: 0,
    errors: [],
    details: []
};
/**
 * Make HTTP request with proper error handling
 */
function makeRequest(options, data = null) {
    return new Promise((resolve, reject) => {
        const req = https.request(options, (res) => {
            let body = '';
            res.on('data', (chunk) => {
                body += chunk;
            });
            res.on('end', () => {
                try {
                    const response = {
                        statusCode: res.statusCode,
                        headers: res.headers,
                        body: body,
                        data: body ? JSON.parse(body) : null
                    };
                    resolve(response);
                }
                catch (error) {
                    resolve({
                        statusCode: res.statusCode,
                        headers: res.headers,
                        body: body,
                        data: null,
                        parseError: error.message
                    });
                }
            });
        });
        req.on('error', (error) => {
            reject(new Error(`Request failed: ${error.message}`));
        });
        req.on('timeout', () => {
            req.destroy();
            reject(new Error('Request timeout'));
        });
        req.setTimeout(CONFIG.REQUEST_TIMEOUT);
        if (data) {
            req.write(JSON.stringify(data));
        }
        req.end();
    });
}
/**
 * Create request options for API calls
 */
function createRequestOptions(path, method = 'POST', apiKey = CONFIG.VALID_API_KEY) {
    const url = new URL(CONFIG.API_BASE_URL + path);
    return {
        hostname: url.hostname,
        port: url.port || 443,
        path: url.pathname + url.search,
        method: method,
        headers: {
            'Content-Type': 'application/json',
            'X-API-Key': apiKey,
            'User-Agent': 'VibePMAgent-TestClient/1.0'
        }
    };
}
/**
 * Log test result
 */
function logTest(testName, passed, details = null, error = null) {
    const status = passed ? '✅ PASS' : '❌ FAIL';
    console.log(`${status} ${testName}`);
    if (CONFIG.VERBOSE && details) {
        console.log(`   Details: ${JSON.stringify(details, null, 2)}`);
    }
    if (error) {
        console.log(`   Error: ${error}`);
        testResults.errors.push({ test: testName, error: error });
    }
    testResults.details.push({
        test: testName,
        passed,
        details,
        error
    });
    if (passed) {
        testResults.passed++;
    }
    else {
        testResults.failed++;
    }
}
/**
 * Test authentication with valid API key
 */
async function testValidAuthentication() {
    try {
        const options = createRequestOptions('/health', 'GET', CONFIG.VALID_API_KEY);
        const response = await makeRequest(options);
        const passed = response.statusCode === 200;
        logTest('Valid API Key Authentication', passed, {
            statusCode: response.statusCode,
            hasData: !!response.data
        }, passed ? null : `Expected 200, got ${response.statusCode}`);
        return passed;
    }
    catch (error) {
        logTest('Valid API Key Authentication', false, null, error.message);
        return false;
    }
}
/**
 * Test authentication with invalid API key
 */
async function testInvalidAuthentication() {
    try {
        const options = createRequestOptions('/health', 'GET', CONFIG.INVALID_API_KEY);
        const response = await makeRequest(options);
        const passed = response.statusCode === 401;
        logTest('Invalid API Key Authentication', passed, {
            statusCode: response.statusCode,
            errorMessage: response.data?.error?.message
        }, passed ? null : `Expected 401, got ${response.statusCode}`);
        return passed;
    }
    catch (error) {
        logTest('Invalid API Key Authentication', false, null, error.message);
        return false;
    }
}
/**
 * Test authentication with missing API key
 */
async function testMissingAuthentication() {
    try {
        const options = createRequestOptions('/health', 'GET', '');
        delete options.headers['X-API-Key'];
        const response = await makeRequest(options);
        const passed = response.statusCode === 401;
        logTest('Missing API Key Authentication', passed, {
            statusCode: response.statusCode,
            errorMessage: response.data?.error?.message
        }, passed ? null : `Expected 401, got ${response.statusCode}`);
        return passed;
    }
    catch (error) {
        logTest('Missing API Key Authentication', false, null, error.message);
        return false;
    }
}
/**
 * Test health check endpoint
 */
async function testHealthCheck() {
    try {
        const options = createRequestOptions('/health', 'GET');
        const response = await makeRequest(options);
        const passed = response.statusCode === 200 && response.data?.status === 'healthy';
        logTest('Health Check Endpoint', passed, {
            statusCode: response.statusCode,
            status: response.data?.status,
            timestamp: response.data?.timestamp
        }, passed ? null : 'Health check failed or returned unexpected data');
        return passed;
    }
    catch (error) {
        logTest('Health Check Endpoint', false, null, error.message);
        return false;
    }
}
/**
 * Test business analysis tools
 */
async function testBusinessAnalysisTools() {
    const tests = [
        {
            name: 'Analyze Business Opportunity',
            path: '/tools',
            data: {
                toolName: 'analyze_business_opportunity',
                toolArgs: {
                    idea: 'AI-powered code review assistant for development teams',
                    market_context: {
                        industry: 'developer_tools',
                        budget_range: 'medium',
                        timeline: '6_months'
                    }
                }
            }
        },
        {
            name: 'Generate Business Case',
            path: '/tools',
            data: {
                toolName: 'generate_business_case',
                toolArgs: {
                    opportunity_analysis: 'Market analysis shows strong demand for automated code review tools with 40% market growth.',
                    financial_inputs: {
                        development_cost: 500000,
                        expected_revenue: 2000000,
                        operational_cost: 100000,
                        time_to_market: 12
                    }
                }
            }
        },
        {
            name: 'Validate Idea Quick',
            path: '/tools',
            data: {
                toolName: 'validate_idea_quick',
                toolArgs: {
                    idea: 'Real-time collaboration platform for remote teams',
                    criteria: ['market_viability', 'technical_feasibility', 'competitive_advantage']
                }
            }
        },
        {
            name: 'Validate Market Timing',
            path: '/tools',
            data: {
                toolName: 'validate_market_timing',
                toolArgs: {
                    feature_idea: 'AI-powered customer support automation',
                    market_signals: {
                        customer_demand: 'high',
                        competitive_pressure: 'medium',
                        technical_readiness: 'high',
                        resource_availability: 'medium'
                    }
                }
            }
        }
    ];
    const results = [];
    for (const test of tests) {
        try {
            const options = createRequestOptions(test.path, 'POST');
            const response = await makeRequest(options, test.data);
            const passed = response.statusCode === 200 && response.data?.success !== false;
            logTest(test.name, passed, {
                statusCode: response.statusCode,
                hasResult: !!response.data?.result || !!response.data?.data,
                toolName: response.data?.toolName
            }, passed ? null : `Request failed: ${response.data?.error || 'Unknown error'}`);
            results.push(passed);
        }
        catch (error) {
            logTest(test.name, false, null, error.message);
            results.push(false);
        }
    }
    return results.every(result => result);
}
/**
 * Test interview preparation tools
 */
async function testInterviewPrepTools() {
    const tests = [
        {
            name: 'Start Interview Preparation',
            path: '/tools',
            data: {
                toolName: 'start_interview_preparation',
                toolArgs: {
                    role_level: 'PM',
                    target_company: 'Google',
                    preparation_timeline: '2 weeks'
                }
            }
        },
        {
            name: 'Generate Interview Question',
            path: '/tools',
            data: {
                toolName: 'generate_interview_question',
                toolArgs: {
                    role_level: 'Senior PM',
                    question_category: 'product_sense',
                    difficulty_level: 3,
                    company_context: 'Meta'
                }
            }
        },
        {
            name: 'Evaluate Interview Response',
            path: '/tools',
            data: {
                toolName: 'evaluate_interview_response',
                toolArgs: {
                    question_id: 'test-q-123',
                    user_response: 'I would approach this product decision by first understanding the user needs through research, then analyzing the competitive landscape, and finally prioritizing features based on impact and effort using a framework like RICE.',
                    evaluation_focus: ['frameworks', 'structure', 'specificity']
                }
            }
        }
    ];
    const results = [];
    for (const test of tests) {
        try {
            const options = createRequestOptions(test.path, 'POST');
            const response = await makeRequest(options, test.data);
            const passed = response.statusCode === 200 && response.data?.success !== false;
            logTest(test.name, passed, {
                statusCode: response.statusCode,
                hasResult: !!response.data?.result || !!response.data?.data,
                toolName: response.data?.toolName
            }, passed ? null : `Request failed: ${response.data?.error || 'Unknown error'}`);
            results.push(passed);
        }
        catch (error) {
            logTest(test.name, false, null, error.message);
            results.push(false);
        }
    }
    return results.every(result => result);
}
/**
 * Test communication tools
 */
async function testCommunicationTools() {
    const tests = [
        {
            name: 'Generate Executive Onepager',
            path: '/tools',
            data: {
                toolName: 'generate_management_onepager',
                toolArgs: {
                    project_info: 'AI-powered customer support automation project with $2M revenue potential and 18-month timeline',
                    audience: 'executives'
                }
            }
        },
        {
            name: 'Create Stakeholder Communication',
            path: '/tools',
            data: {
                toolName: 'create_stakeholder_communication',
                toolArgs: {
                    business_case: 'Comprehensive business case showing 300% ROI over 3 years with strong market validation',
                    communication_type: 'executive_onepager',
                    audience: 'executives'
                }
            }
        },
        {
            name: 'Generate PR-FAQ',
            path: '/tools',
            data: {
                toolName: 'generate_pr_faq',
                toolArgs: {
                    product_info: 'Revolutionary AI-powered development assistant that increases coding productivity by 40%',
                    target_audience: 'software developers'
                }
            }
        }
    ];
    const results = [];
    for (const test of tests) {
        try {
            const options = createRequestOptions(test.path, 'POST');
            const response = await makeRequest(options, test.data);
            const passed = response.statusCode === 200 && response.data?.success !== false;
            logTest(test.name, passed, {
                statusCode: response.statusCode,
                hasResult: !!response.data?.result || !!response.data?.data,
                toolName: response.data?.toolName
            }, passed ? null : `Request failed: ${response.data?.error || 'Unknown error'}`);
            results.push(passed);
        }
        catch (error) {
            logTest(test.name, false, null, error.message);
            results.push(false);
        }
    }
    return results.every(result => result);
}
/**
 * Test error handling for malformed requests
 */
async function testErrorHandling() {
    const tests = [
        {
            name: 'Invalid Tool Name',
            path: '/tools',
            data: {
                toolName: 'nonexistent_tool',
                toolArgs: {}
            },
            expectedStatus: 400
        },
        {
            name: 'Missing Tool Args',
            path: '/tools',
            data: {
                toolName: 'validate_idea_quick'
                // Missing toolArgs
            },
            expectedStatus: 400
        },
        {
            name: 'Invalid JSON',
            path: '/tools',
            data: 'invalid json',
            expectedStatus: 400
        }
    ];
    const results = [];
    for (const test of tests) {
        try {
            const options = createRequestOptions(test.path, 'POST');
            const response = await makeRequest(options, test.data);
            const passed = response.statusCode === test.expectedStatus;
            logTest(test.name, passed, {
                statusCode: response.statusCode,
                expectedStatus: test.expectedStatus,
                errorMessage: response.data?.error?.message
            }, passed ? null : `Expected ${test.expectedStatus}, got ${response.statusCode}`);
            results.push(passed);
        }
        catch (error) {
            logTest(test.name, false, null, error.message);
            results.push(false);
        }
    }
    return results.every(result => result);
}
/**
 * Test CORS headers
 */
async function testCORSHeaders() {
    try {
        const options = createRequestOptions('/health', 'OPTIONS');
        const response = await makeRequest(options);
        const hasCORSHeaders = response.headers['access-control-allow-origin'] &&
            response.headers['access-control-allow-methods'];
        const passed = response.statusCode === 200 && hasCORSHeaders;
        logTest('CORS Headers', passed, {
            statusCode: response.statusCode,
            corsOrigin: response.headers['access-control-allow-origin'],
            corsMethods: response.headers['access-control-allow-methods'],
            corsHeaders: response.headers['access-control-allow-headers']
        }, passed ? null : 'Missing CORS headers or unexpected status code');
        return passed;
    }
    catch (error) {
        logTest('CORS Headers', false, null, error.message);
        return false;
    }
}
/**
 * Test rate limiting (if implemented)
 */
async function testRateLimiting() {
    console.log('\n🔄 Testing rate limiting (making multiple rapid requests)...');
    const requests = [];
    const startTime = Date.now();
    // Make 10 rapid requests
    for (let i = 0; i < 10; i++) {
        const options = createRequestOptions('/health', 'GET');
        requests.push(makeRequest(options));
    }
    try {
        const responses = await Promise.all(requests);
        const endTime = Date.now();
        const duration = endTime - startTime;
        const successCount = responses.filter(r => r.statusCode === 200).length;
        const rateLimitedCount = responses.filter(r => r.statusCode === 429).length;
        // Rate limiting is optional, so we just report the results
        logTest('Rate Limiting Test', true, {
            totalRequests: 10,
            successfulRequests: successCount,
            rateLimitedRequests: rateLimitedCount,
            durationMs: duration,
            avgResponseTime: duration / 10
        });
        return true;
    }
    catch (error) {
        logTest('Rate Limiting Test', false, null, error.message);
        return false;
    }
}
/**
 * Run all tests
 */
async function runAllTests() {
    console.log('🚀 Starting External API Access Tests');
    console.log(`📍 API Base URL: ${CONFIG.API_BASE_URL}`);
    console.log(`🔑 Using API Key: ${CONFIG.VALID_API_KEY.substring(0, 8)}...`);
    console.log('');
    // Authentication tests
    console.log('🔐 Testing Authentication...');
    await testValidAuthentication();
    await testInvalidAuthentication();
    await testMissingAuthentication();
    console.log('');
    // Basic functionality tests
    console.log('🏥 Testing Basic Functionality...');
    await testHealthCheck();
    await testCORSHeaders();
    console.log('');
    // MCP tool tests
    console.log('💼 Testing Business Analysis Tools...');
    await testBusinessAnalysisTools();
    console.log('');
    console.log('🎯 Testing Interview Preparation Tools...');
    await testInterviewPrepTools();
    console.log('');
    console.log('📝 Testing Communication Tools...');
    await testCommunicationTools();
    console.log('');
    // Error handling tests
    console.log('⚠️  Testing Error Handling...');
    await testErrorHandling();
    console.log('');
    // Performance tests
    await testRateLimiting();
    console.log('');
    // Print summary
    console.log('📊 Test Summary');
    console.log('================');
    console.log(`✅ Passed: ${testResults.passed}`);
    console.log(`❌ Failed: ${testResults.failed}`);
    console.log(`📈 Success Rate: ${((testResults.passed / (testResults.passed + testResults.failed)) * 100).toFixed(1)}%`);
    if (testResults.failed > 0) {
        console.log('\n❌ Failed Tests:');
        testResults.errors.forEach(error => {
            console.log(`   • ${error.test}: ${error.error}`);
        });
    }
    console.log('\n🎯 Test Results Summary:');
    testResults.details.forEach(detail => {
        const status = detail.passed ? '✅' : '❌';
        console.log(`   ${status} ${detail.test}`);
    });
    // Exit with appropriate code
    process.exit(testResults.failed > 0 ? 1 : 0);
}
/**
 * Main execution
 */
if (require.main === module) {
    // Check if API Gateway URL is provided
    if (!process.env.API_GATEWAY_URL && CONFIG.API_BASE_URL.includes('your-api-id')) {
        console.error('❌ Error: Please set API_GATEWAY_URL environment variable');
        console.error('   Example: API_GATEWAY_URL=https://abc123.execute-api.us-east-1.amazonaws.com/dev npm run test:external');
        process.exit(1);
    }
    runAllTests().catch(error => {
        console.error('❌ Test execution failed:', error.message);
        process.exit(1);
    });
}
module.exports = {
    runAllTests,
    testValidAuthentication,
    testInvalidAuthentication,
    testBusinessAnalysisTools,
    testInterviewPrepTools,
    testCommunicationTools,
    testErrorHandling
};
//# sourceMappingURL=test-external-api-access.js.map