import { Context, APIGatewayProxyResult, APIGatewayEvent } from 'aws-lambda';
import { LambdaResponse } from './shared/types';
export declare enum InvocationContext {
    EXTERNAL_API_GATEWAY = "external",
    INTERNAL_DIRECT = "internal",
    INTERNAL_BEDROCK = "bedrock"
}
export interface DirectInvocationEvent {
    toolName: string;
    toolArgs: Record<string, any>;
    source?: string;
    requestId?: string;
}
export declare const handler: (event: APIGatewayEvent | DirectInvocationEvent, context: Context) => Promise<APIGatewayProxyResult | LambdaResponse>;
//# sourceMappingURL=router.d.ts.map