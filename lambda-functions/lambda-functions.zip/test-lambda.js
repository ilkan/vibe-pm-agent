#!/usr/bin/env node
"use strict";
/**
 * Node.js test script for Vibe PM Agent Lambda Functions
 * Provides programmatic testing with detailed output
 */
const { LambdaClient, InvokeCommand } = require('@aws-sdk/client-lambda');
// Configuration
const FUNCTION_NAME = process.env.LAMBDA_FUNCTION_NAME || 'dev-vibe-pm-agent-lambda';
const REGION = process.env.AWS_REGION || 'us-east-1';
const lambda = new LambdaClient({ region: REGION });
// Test cases
const testCases = [
    {
        name: 'Health Check',
        payload: {
            path: '/health',
            httpMethod: 'GET',
            body: null
        }
    },
    {
        name: 'Analyze Business Opportunity',
        payload: {
            path: '/business-analysis/analyze-opportunity',
            httpMethod: 'POST',
            body: JSON.stringify({
                toolName: 'analyze_business_opportunity',
                toolArgs: {
                    idea: 'AI-powered code review assistant for development teams',
                    market_context: {
                        industry: 'Developer Tools',
                        competition: 'GitHub Copilot, CodeRabbit',
                        budget_range: 'medium',
                        timeline: '6 months'
                    }
                }
            })
        }
    },
    {
        name: 'Start Interview Preparation',
        payload: {
            path: '/interview-prep/start-session',
            httpMethod: 'POST',
            body: JSON.stringify({
                toolName: 'start_interview_preparation',
                toolArgs: {
                    role_level: 'Senior PM',
                    target_company: 'Google',
                    preparation_timeline: '2 weeks'
                }
            })
        }
    },
    {
        name: 'Generate Interview Question',
        payload: {
            path: '/interview-prep/generate-question',
            httpMethod: 'POST',
            body: JSON.stringify({
                toolName: 'generate_interview_question',
                toolArgs: {
                    role_level: 'PM',
                    question_category: 'product_sense',
                    difficulty_level: 3
                }
            })
        }
    },
    {
        name: 'Start Case Study',
        payload: {
            path: '/case-studies/start-case',
            httpMethod: 'POST',
            body: JSON.stringify({
                toolName: 'start_case_study',
                toolArgs: {
                    case_type: 'product_design',
                    role_level: 'Senior PM',
                    difficulty_level: 4
                }
            })
        }
    },
    {
        name: 'Quick Idea Validation',
        payload: {
            path: '/business-analysis/validate-idea',
            httpMethod: 'POST',
            body: JSON.stringify({
                toolName: 'validate_idea_quick',
                toolArgs: {
                    idea: 'Mobile app for restaurant reservations with AI recommendations',
                    criteria: ['market_demand', 'technical_feasibility', 'competitive_advantage']
                }
            })
        }
    },
    {
        name: 'Generate Business Case',
        payload: {
            path: '/business-analysis/generate-case',
            httpMethod: 'POST',
            body: JSON.stringify({
                toolName: 'generate_business_case',
                toolArgs: {
                    opportunity_analysis: 'Strong market demand for AI-powered developer tools',
                    financial_inputs: {
                        development_cost: 500000,
                        operational_cost: 100000,
                        expected_revenue: 2000000,
                        time_to_market: 6
                    }
                }
            })
        }
    },
    {
        name: 'Generate PR-FAQ',
        payload: {
            path: '/communications/pr-faq',
            httpMethod: 'POST',
            body: JSON.stringify({
                toolName: 'generate_pr_faq',
                toolArgs: {
                    product_info: 'AI-powered code review assistant that helps development teams ship faster',
                    target_audience: 'Software development teams at tech companies'
                }
            })
        }
    }
];
// Invoke Lambda function
async function invokeLambda(testCase) {
    console.log(`\n${'='.repeat(60)}`);
    console.log(`Testing: ${testCase.name}`);
    console.log('='.repeat(60));
    const startTime = Date.now();
    try {
        const command = new InvokeCommand({
            FunctionName: FUNCTION_NAME,
            Payload: JSON.stringify(testCase.payload)
        });
        const response = await lambda.send(command);
        const executionTime = Date.now() - startTime;
        // Parse response
        const responsePayload = JSON.parse(Buffer.from(response.Payload).toString());
        console.log(`\n✅ Status: SUCCESS`);
        console.log(`⏱️  Execution Time: ${executionTime}ms`);
        console.log(`📊 Status Code: ${responsePayload.statusCode || 'N/A'}`);
        // Parse body if it's a string
        let body = responsePayload.body;
        if (typeof body === 'string') {
            try {
                body = JSON.parse(body);
            }
            catch (e) {
                // Keep as string if not JSON
            }
        }
        console.log('\n📦 Response:');
        console.log(JSON.stringify(body, null, 2));
        return {
            success: true,
            testName: testCase.name,
            executionTime,
            response: body
        };
    }
    catch (error) {
        const executionTime = Date.now() - startTime;
        console.log(`\n❌ Status: FAILED`);
        console.log(`⏱️  Execution Time: ${executionTime}ms`);
        console.log(`\n🔴 Error:`);
        console.error(error.message);
        return {
            success: false,
            testName: testCase.name,
            executionTime,
            error: error.message
        };
    }
}
// Run all tests
async function runAllTests() {
    console.log('\n🚀 Vibe PM Agent Lambda Testing Suite');
    console.log(`📍 Function: ${FUNCTION_NAME}`);
    console.log(`🌍 Region: ${REGION}`);
    console.log(`⏰ Started: ${new Date().toISOString()}\n`);
    const results = [];
    for (const testCase of testCases) {
        const result = await invokeLambda(testCase);
        results.push(result);
        // Wait between tests to avoid throttling
        await new Promise(resolve => setTimeout(resolve, 1000));
    }
    // Summary
    console.log('\n' + '='.repeat(60));
    console.log('📊 TEST SUMMARY');
    console.log('='.repeat(60));
    const successful = results.filter(r => r.success).length;
    const failed = results.filter(r => !r.success).length;
    const totalTime = results.reduce((sum, r) => sum + r.executionTime, 0);
    const avgTime = totalTime / results.length;
    console.log(`\n✅ Successful: ${successful}/${results.length}`);
    console.log(`❌ Failed: ${failed}/${results.length}`);
    console.log(`⏱️  Total Time: ${totalTime}ms`);
    console.log(`📈 Average Time: ${Math.round(avgTime)}ms`);
    if (failed > 0) {
        console.log('\n🔴 Failed Tests:');
        results.filter(r => !r.success).forEach(r => {
            console.log(`  - ${r.testName}: ${r.error}`);
        });
    }
    console.log('\n✨ Testing completed!\n');
    process.exit(failed > 0 ? 1 : 0);
}
// Run specific test
async function runSpecificTest(testName) {
    const testCase = testCases.find(t => t.name.toLowerCase().includes(testName.toLowerCase()));
    if (!testCase) {
        console.error(`❌ Test not found: ${testName}`);
        console.log('\nAvailable tests:');
        testCases.forEach(t => console.log(`  - ${t.name}`));
        process.exit(1);
    }
    await invokeLambda(testCase);
}
// Main
const args = process.argv.slice(2);
if (args.length > 0 && args[0] !== 'all') {
    runSpecificTest(args[0]);
}
else {
    runAllTests();
}
//# sourceMappingURL=test-lambda.js.map