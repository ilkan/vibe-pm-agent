#!/usr/bin/env node
"use strict";
/**
 * Test script for API key validation and external access patterns
 * Tests the Lambda handler directly with different event types
 */
// Set the correct path for credentials before requiring the handler
process.env.CREDENTIAL_PATH = '../.aws/api-keys.json';
const { handler } = require('./dist/router');
const crypto = require('crypto');
// Test configuration
const TEST_CONFIG = {
    VALID_API_KEY: 'test-api-key-12345678901234567890',
    INVALID_API_KEY: 'invalid-key-123',
    VERBOSE: process.env.VERBOSE === 'true'
};
// Mock Lambda context
const mockContext = {
    awsRequestId: 'test-request-' + Date.now(),
    functionName: 'vibe-pm-agent-test',
    invokedFunctionArn: 'arn:aws:lambda:us-east-1:123456789012:function:vibe-pm-agent-test',
    remainingTimeInMillis: 30000,
    callbackWaitsForEmptyEventLoop: false
};
// Test results
const testResults = {
    passed: 0,
    failed: 0,
    tests: []
};
/**
 * Log test result
 */
function logTest(testName, passed, details = null, error = null) {
    const status = passed ? '✅ PASS' : '❌ FAIL';
    console.log(`${status} ${testName}`);
    if (TEST_CONFIG.VERBOSE && details) {
        console.log(`   Details: ${JSON.stringify(details, null, 2)}`);
    }
    if (error) {
        console.log(`   Error: ${error}`);
    }
    testResults.tests.push({
        name: testName,
        passed,
        details,
        error
    });
    if (passed) {
        testResults.passed++;
    }
    else {
        testResults.failed++;
    }
}
/**
 * Test external request with valid API key
 */
async function testValidApiKeyExternal() {
    const event = {
        requestContext: {
            identity: { sourceIp: '192.168.1.1' },
            requestId: 'test-req-1'
        },
        headers: {
            'Content-Type': 'application/json',
            'X-API-Key': TEST_CONFIG.VALID_API_KEY
        },
        httpMethod: 'POST',
        path: '/tools',
        body: JSON.stringify({
            toolName: 'validate_idea_quick',
            toolArgs: {
                idea: 'AI-powered code review assistant',
                criteria: ['feasibility', 'market-demand']
            }
        })
    };
    try {
        const result = await handler(event, mockContext);
        const passed = result.statusCode === 200;
        logTest('External Request - Valid API Key', passed, {
            statusCode: result.statusCode,
            hasBody: !!result.body,
            contentType: result.headers?.['Content-Type']
        }, passed ? null : `Expected 200, got ${result.statusCode}`);
        return passed;
    }
    catch (error) {
        logTest('External Request - Valid API Key', false, null, error.message);
        return false;
    }
}
/**
 * Test external request with invalid API key
 */
async function testInvalidApiKeyExternal() {
    const event = {
        requestContext: {
            identity: { sourceIp: '192.168.1.1' },
            requestId: 'test-req-2'
        },
        headers: {
            'Content-Type': 'application/json',
            'X-API-Key': TEST_CONFIG.INVALID_API_KEY
        },
        httpMethod: 'POST',
        path: '/tools',
        body: JSON.stringify({
            toolName: 'validate_idea_quick',
            toolArgs: {
                idea: 'Test idea',
                criteria: ['feasibility']
            }
        })
    };
    try {
        const result = await handler(event, mockContext);
        const passed = result.statusCode === 401;
        logTest('External Request - Invalid API Key', passed, {
            statusCode: result.statusCode,
            errorMessage: result.body ? JSON.parse(result.body).error?.message : null
        }, passed ? null : `Expected 401, got ${result.statusCode}`);
        return passed;
    }
    catch (error) {
        logTest('External Request - Invalid API Key', false, null, error.message);
        return false;
    }
}
/**
 * Test external request with missing API key
 */
async function testMissingApiKeyExternal() {
    const event = {
        requestContext: {
            identity: { sourceIp: '192.168.1.1' },
            requestId: 'test-req-3'
        },
        headers: {
            'Content-Type': 'application/json'
            // No X-API-Key header
        },
        httpMethod: 'POST',
        path: '/tools',
        body: JSON.stringify({
            toolName: 'validate_idea_quick',
            toolArgs: {
                idea: 'Test idea',
                criteria: ['feasibility']
            }
        })
    };
    try {
        const result = await handler(event, mockContext);
        const passed = result.statusCode === 401;
        logTest('External Request - Missing API Key', passed, {
            statusCode: result.statusCode,
            errorMessage: result.body ? JSON.parse(result.body).error?.message : null
        }, passed ? null : `Expected 401, got ${result.statusCode}`);
        return passed;
    }
    catch (error) {
        logTest('External Request - Missing API Key', false, null, error.message);
        return false;
    }
}
/**
 * Test health check endpoint (should work without API key)
 */
async function testHealthCheckExternal() {
    const event = {
        requestContext: {
            identity: { sourceIp: '192.168.1.1' },
            requestId: 'test-req-health'
        },
        headers: {
            'Content-Type': 'application/json'
        },
        httpMethod: 'GET',
        path: '/health'
    };
    try {
        const result = await handler(event, mockContext);
        const passed = result.statusCode === 200;
        const responseBody = result.body ? JSON.parse(result.body) : null;
        logTest('Health Check - No Auth Required', passed, {
            statusCode: result.statusCode,
            status: responseBody?.status,
            timestamp: responseBody?.timestamp
        }, passed ? null : `Expected 200, got ${result.statusCode}`);
        return passed;
    }
    catch (error) {
        logTest('Health Check - No Auth Required', false, null, error.message);
        return false;
    }
}
/**
 * Test internal direct invocation (should bypass auth)
 */
async function testInternalDirectInvocation() {
    const event = {
        toolName: 'validate_idea_quick',
        toolArgs: {
            idea: 'Internal test idea',
            criteria: ['feasibility', 'market-demand']
        },
        source: 'bedrock-agent'
    };
    try {
        const result = await handler(event, mockContext);
        const passed = result.success === true || result.statusCode === 200;
        logTest('Internal Direct Invocation', passed, {
            success: result.success,
            toolName: result.toolName,
            hasResult: !!result.result || !!result.data
        }, passed ? null : 'Internal invocation failed');
        return passed;
    }
    catch (error) {
        logTest('Internal Direct Invocation', false, null, error.message);
        return false;
    }
}
/**
 * Test multiple MCP tools through external API
 */
async function testMultipleMCPTools() {
    const tools = [
        {
            name: 'Analyze Business Opportunity',
            toolName: 'analyze_business_opportunity',
            toolArgs: {
                idea: 'AI-powered customer support automation',
                market_context: {
                    industry: 'saas',
                    budget_range: 'medium'
                }
            }
        },
        {
            name: 'Generate Business Case',
            toolName: 'generate_business_case',
            toolArgs: {
                opportunity_analysis: 'Strong market demand with 40% growth potential',
                financial_inputs: {
                    development_cost: 500000,
                    expected_revenue: 2000000
                }
            }
        },
        {
            name: 'Start Interview Preparation',
            toolName: 'start_interview_preparation',
            toolArgs: {
                role_level: 'PM',
                target_company: 'Google'
            }
        }
    ];
    let allPassed = true;
    for (const tool of tools) {
        const event = {
            requestContext: {
                identity: { sourceIp: '192.168.1.1' },
                requestId: `test-req-${tool.toolName}`
            },
            headers: {
                'Content-Type': 'application/json',
                'X-API-Key': TEST_CONFIG.VALID_API_KEY
            },
            httpMethod: 'POST',
            path: '/tools',
            body: JSON.stringify({
                toolName: tool.toolName,
                toolArgs: tool.toolArgs
            })
        };
        try {
            const result = await handler(event, mockContext);
            const passed = result.statusCode === 200;
            logTest(`MCP Tool: ${tool.name}`, passed, {
                statusCode: result.statusCode,
                toolName: tool.toolName,
                hasResult: result.body ? !!JSON.parse(result.body).result : false
            }, passed ? null : `Tool ${tool.toolName} failed`);
            if (!passed)
                allPassed = false;
        }
        catch (error) {
            logTest(`MCP Tool: ${tool.name}`, false, null, error.message);
            allPassed = false;
        }
    }
    return allPassed;
}
/**
 * Test environment variable configuration
 */
async function testEnvironmentConfiguration() {
    // Test with external access disabled
    const originalValue = process.env.EXTERNAL_ACCESS_ENABLED;
    try {
        // Disable external access
        process.env.EXTERNAL_ACCESS_ENABLED = 'false';
        const event = {
            requestContext: {
                identity: { sourceIp: '192.168.1.1' },
                requestId: 'test-req-disabled'
            },
            headers: {
                'Content-Type': 'application/json',
                'X-API-Key': TEST_CONFIG.VALID_API_KEY
            },
            httpMethod: 'POST',
            path: '/tools',
            body: JSON.stringify({
                toolName: 'validate_idea_quick',
                toolArgs: {
                    idea: 'Test idea',
                    criteria: ['feasibility']
                }
            })
        };
        const result = await handler(event, mockContext);
        const passed = result.statusCode === 403; // Should be forbidden when disabled
        logTest('External Access Disabled', passed, {
            statusCode: result.statusCode,
            externalAccessEnabled: process.env.EXTERNAL_ACCESS_ENABLED
        }, passed ? null : `Expected 403 when external access disabled, got ${result.statusCode}`);
        return passed;
    }
    catch (error) {
        logTest('External Access Disabled', false, null, error.message);
        return false;
    }
    finally {
        // Restore original value
        if (originalValue !== undefined) {
            process.env.EXTERNAL_ACCESS_ENABLED = originalValue;
        }
        else {
            delete process.env.EXTERNAL_ACCESS_ENABLED;
        }
    }
}
/**
 * Run all tests
 */
async function runAllTests() {
    console.log('🚀 Starting API Key Validation Tests');
    console.log(`🔑 Valid API Key: ${TEST_CONFIG.VALID_API_KEY.substring(0, 8)}...`);
    console.log(`🔑 Invalid API Key: ${TEST_CONFIG.INVALID_API_KEY}`);
    console.log('');
    // Set environment for testing
    process.env.EXTERNAL_ACCESS_ENABLED = 'true';
    process.env.ENVIRONMENT = 'dev';
    console.log('🔐 Testing Authentication...');
    await testValidApiKeyExternal();
    await testInvalidApiKeyExternal();
    await testMissingApiKeyExternal();
    console.log('');
    console.log('🏥 Testing Health Check...');
    await testHealthCheckExternal();
    console.log('');
    console.log('🔄 Testing Internal Access...');
    await testInternalDirectInvocation();
    console.log('');
    console.log('🛠️  Testing MCP Tools...');
    await testMultipleMCPTools();
    console.log('');
    console.log('⚙️  Testing Configuration...');
    await testEnvironmentConfiguration();
    console.log('');
    // Print summary
    console.log('📊 Test Summary');
    console.log('================');
    console.log(`✅ Passed: ${testResults.passed}`);
    console.log(`❌ Failed: ${testResults.failed}`);
    console.log(`📈 Success Rate: ${((testResults.passed / (testResults.passed + testResults.failed)) * 100).toFixed(1)}%`);
    if (testResults.failed > 0) {
        console.log('\n❌ Failed Tests:');
        testResults.tests.filter(t => !t.passed).forEach(test => {
            console.log(`   • ${test.name}: ${test.error || 'Unknown error'}`);
        });
    }
    // Exit with appropriate code
    process.exit(testResults.failed > 0 ? 1 : 0);
}
/**
 * Main execution
 */
if (require.main === module) {
    runAllTests().catch(error => {
        console.error('❌ Test execution failed:', error.message);
        process.exit(1);
    });
}
module.exports = {
    runAllTests,
    testValidApiKeyExternal,
    testInvalidApiKeyExternal,
    testInternalDirectInvocation,
    testMultipleMCPTools
};
//# sourceMappingURL=test-api-key-validation.js.map