"use strict";
// Simple test script to verify dual access patterns work
const { handler } = require('./router');
// Mock context
const mockContext = {
    awsRequestId: 'test-request-123',
    functionName: 'vibe-pm-agent-test',
    invokedFunctionArn: 'arn:aws:lambda:us-east-1:123456789012:function:vibe-pm-agent-test',
    remainingTimeInMillis: 30000
};
// Test 1: External API Gateway request (should require authentication)
async function testExternalRequest() {
    console.log('Testing external API Gateway request...');
    const apiGatewayEvent = {
        requestContext: {
            identity: { sourceIp: '192.168.1.1' }
        },
        headers: {
            'Content-Type': 'application/json',
            'X-API-Key': 'test-api-key-12345678901234567890'
        },
        httpMethod: 'POST',
        path: '/tools',
        body: JSON.stringify({
            toolName: 'validate_idea_quick',
            toolArgs: {
                idea: 'Test feature idea',
                criteria: ['feasibility', 'market-demand']
            }
        })
    };
    try {
        const result = await handler(apiGatewayEvent, mockContext);
        console.log('External request result:', {
            statusCode: result.statusCode,
            success: result.statusCode === 200 || result.statusCode === 401 // 401 expected without valid API key
        });
    }
    catch (error) {
        console.log('External request error (expected):', error.message);
    }
}
// Test 2: Internal direct invocation (should bypass authentication)
async function testInternalRequest() {
    console.log('Testing internal direct invocation...');
    const directInvocationEvent = {
        toolName: 'validate_idea_quick',
        toolArgs: {
            idea: 'Test feature idea',
            criteria: ['feasibility', 'market-demand']
        },
        source: 'bedrock-agent'
    };
    try {
        const result = await handler(directInvocationEvent, mockContext);
        console.log('Internal request result:', {
            success: result.success,
            toolName: result.toolName
        });
    }
    catch (error) {
        console.log('Internal request error:', error.message);
    }
}
// Test 3: Health check (should work without authentication)
async function testHealthCheck() {
    console.log('Testing health check endpoint...');
    const healthCheckEvent = {
        requestContext: {
            identity: { sourceIp: '192.168.1.1' }
        },
        headers: {
            'Content-Type': 'application/json'
        },
        httpMethod: 'GET',
        path: '/health'
    };
    try {
        const result = await handler(healthCheckEvent, mockContext);
        console.log('Health check result:', {
            statusCode: result.statusCode,
            success: result.statusCode === 200
        });
    }
    catch (error) {
        console.log('Health check error:', error.message);
    }
}
// Run tests
async function runTests() {
    console.log('=== Testing Dual Access Patterns ===\n');
    // Set environment variable for testing
    process.env.EXTERNAL_ACCESS_ENABLED = 'true';
    process.env.ENVIRONMENT = 'dev';
    await testHealthCheck();
    console.log('');
    await testExternalRequest();
    console.log('');
    await testInternalRequest();
    console.log('');
    console.log('=== Tests Complete ===');
}
runTests().catch(console.error);
//# sourceMappingURL=test-dual-access.js.map